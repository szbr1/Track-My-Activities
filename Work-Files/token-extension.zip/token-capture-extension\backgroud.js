// Save tokens received from content-script.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "saveToken") {
      chrome.storage.local.set({ token: request.token });
      console.log("Token saved:", request.token); // Debug
    }
  });