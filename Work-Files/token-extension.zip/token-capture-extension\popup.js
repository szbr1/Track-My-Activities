chrome.storage.local.get(["token"], (data) => {
    document.getElementById("token-status").innerText = 
      data.token ? `Token: ${data.token.slice(0, 10)}...` : "No token found.";
  });